gdjs.INFOCode = {};
gdjs.INFOCode.GDNewObject3Objects1= [];
gdjs.INFOCode.GDNewObject3Objects2= [];
gdjs.INFOCode.GDNewObjectObjects1= [];
gdjs.INFOCode.GDNewObjectObjects2= [];
gdjs.INFOCode.GDNewObject2Objects1= [];
gdjs.INFOCode.GDNewObject2Objects2= [];
gdjs.INFOCode.GDNewObject32Objects1= [];
gdjs.INFOCode.GDNewObject32Objects2= [];
gdjs.INFOCode.GDNewObject5Objects1= [];
gdjs.INFOCode.GDNewObject5Objects2= [];
gdjs.INFOCode.GDNewObject4Objects1= [];
gdjs.INFOCode.GDNewObject4Objects2= [];

gdjs.INFOCode.conditionTrue_0 = {val:false};
gdjs.INFOCode.condition0IsTrue_0 = {val:false};
gdjs.INFOCode.condition1IsTrue_0 = {val:false};


gdjs.INFOCode.eventsList0 = function(runtimeScene) {

{


gdjs.INFOCode.condition0IsTrue_0.val = false;
{
gdjs.INFOCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.INFOCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "scene1", false);
}}

}


};

gdjs.INFOCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.INFOCode.GDNewObject3Objects1.length = 0;
gdjs.INFOCode.GDNewObject3Objects2.length = 0;
gdjs.INFOCode.GDNewObjectObjects1.length = 0;
gdjs.INFOCode.GDNewObjectObjects2.length = 0;
gdjs.INFOCode.GDNewObject2Objects1.length = 0;
gdjs.INFOCode.GDNewObject2Objects2.length = 0;
gdjs.INFOCode.GDNewObject32Objects1.length = 0;
gdjs.INFOCode.GDNewObject32Objects2.length = 0;
gdjs.INFOCode.GDNewObject5Objects1.length = 0;
gdjs.INFOCode.GDNewObject5Objects2.length = 0;
gdjs.INFOCode.GDNewObject4Objects1.length = 0;
gdjs.INFOCode.GDNewObject4Objects2.length = 0;

gdjs.INFOCode.eventsList0(runtimeScene);
return;

}

gdjs['INFOCode'] = gdjs.INFOCode;
