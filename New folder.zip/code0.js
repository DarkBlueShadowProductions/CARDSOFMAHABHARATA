gdjs.scene1Code = {};
gdjs.scene1Code.GDNewSpriteObjects1= [];
gdjs.scene1Code.GDNewSpriteObjects2= [];
gdjs.scene1Code.GDNewSprite2Objects1= [];
gdjs.scene1Code.GDNewSprite2Objects2= [];
gdjs.scene1Code.GDNewTiledSpriteObjects1= [];
gdjs.scene1Code.GDNewTiledSpriteObjects2= [];
gdjs.scene1Code.GDNewObjectObjects1= [];
gdjs.scene1Code.GDNewObjectObjects2= [];
gdjs.scene1Code.GDNewObject2Objects1= [];
gdjs.scene1Code.GDNewObject2Objects2= [];
gdjs.scene1Code.GDNewObject3222Objects1= [];
gdjs.scene1Code.GDNewObject3222Objects2= [];
gdjs.scene1Code.GDNewObject322Objects1= [];
gdjs.scene1Code.GDNewObject322Objects2= [];
gdjs.scene1Code.GDNewObject32Objects1= [];
gdjs.scene1Code.GDNewObject32Objects2= [];
gdjs.scene1Code.GDNewObject3Objects1= [];
gdjs.scene1Code.GDNewObject3Objects2= [];

gdjs.scene1Code.conditionTrue_0 = {val:false};
gdjs.scene1Code.condition0IsTrue_0 = {val:false};
gdjs.scene1Code.condition1IsTrue_0 = {val:false};


gdjs.scene1Code.eventsList0 = function(runtimeScene) {

{


{
}

}


};gdjs.scene1Code.eventsList1 = function(runtimeScene) {

{


{

{ //Subevents
gdjs.scene1Code.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.scene1Code.mapOfGDgdjs_46scene1Code_46GDNewObject322Objects1Objects = Hashtable.newFrom({"NewObject322": gdjs.scene1Code.GDNewObject322Objects1});gdjs.scene1Code.eventsList2 = function(runtimeScene) {

{


gdjs.scene1Code.condition0IsTrue_0.val = false;
{
gdjs.scene1Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.scene1Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "INFO", false);
}}

}


};gdjs.scene1Code.mapOfGDgdjs_46scene1Code_46GDNewObject3222Objects1Objects = Hashtable.newFrom({"NewObject3222": gdjs.scene1Code.GDNewObject3222Objects1});gdjs.scene1Code.eventsList3 = function(runtimeScene) {

{


gdjs.scene1Code.condition0IsTrue_0.val = false;
{
gdjs.scene1Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.scene1Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "C", false);
}}

}


};gdjs.scene1Code.eventsList4 = function(runtimeScene) {

{


{
}

}


{


{

{ //Subevents
gdjs.scene1Code.eventsList1(runtimeScene);} //End of subevents
}

}


{


{
}

}


{


{
}

}


{


gdjs.scene1Code.condition0IsTrue_0.val = false;
{
gdjs.scene1Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.scene1Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "scene" + gdjs.evtTools.common.toString(gdjs.randomInRange(2, 20)), false);
}}

}


{


gdjs.scene1Code.condition0IsTrue_0.val = false;
{
gdjs.scene1Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "r");
}if (gdjs.scene1Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "scene1", false);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject322"), gdjs.scene1Code.GDNewObject322Objects1);

gdjs.scene1Code.condition0IsTrue_0.val = false;
{
gdjs.scene1Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.scene1Code.mapOfGDgdjs_46scene1Code_46GDNewObject322Objects1Objects, runtimeScene, true, false);
}if (gdjs.scene1Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.scene1Code.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject3222"), gdjs.scene1Code.GDNewObject3222Objects1);

gdjs.scene1Code.condition0IsTrue_0.val = false;
{
gdjs.scene1Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.scene1Code.mapOfGDgdjs_46scene1Code_46GDNewObject3222Objects1Objects, runtimeScene, true, false);
}if (gdjs.scene1Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.scene1Code.eventsList3(runtimeScene);} //End of subevents
}

}


};

gdjs.scene1Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.scene1Code.GDNewSpriteObjects1.length = 0;
gdjs.scene1Code.GDNewSpriteObjects2.length = 0;
gdjs.scene1Code.GDNewSprite2Objects1.length = 0;
gdjs.scene1Code.GDNewSprite2Objects2.length = 0;
gdjs.scene1Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.scene1Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.scene1Code.GDNewObjectObjects1.length = 0;
gdjs.scene1Code.GDNewObjectObjects2.length = 0;
gdjs.scene1Code.GDNewObject2Objects1.length = 0;
gdjs.scene1Code.GDNewObject2Objects2.length = 0;
gdjs.scene1Code.GDNewObject3222Objects1.length = 0;
gdjs.scene1Code.GDNewObject3222Objects2.length = 0;
gdjs.scene1Code.GDNewObject322Objects1.length = 0;
gdjs.scene1Code.GDNewObject322Objects2.length = 0;
gdjs.scene1Code.GDNewObject32Objects1.length = 0;
gdjs.scene1Code.GDNewObject32Objects2.length = 0;
gdjs.scene1Code.GDNewObject3Objects1.length = 0;
gdjs.scene1Code.GDNewObject3Objects2.length = 0;

gdjs.scene1Code.eventsList4(runtimeScene);
return;

}

gdjs['scene1Code'] = gdjs.scene1Code;
