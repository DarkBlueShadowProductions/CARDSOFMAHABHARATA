gdjs.scene8Code = {};
gdjs.scene8Code.GDNewObjectObjects1= [];
gdjs.scene8Code.GDNewObjectObjects2= [];
gdjs.scene8Code.GDNewObject2Objects1= [];
gdjs.scene8Code.GDNewObject2Objects2= [];
gdjs.scene8Code.GDNewObject3Objects1= [];
gdjs.scene8Code.GDNewObject3Objects2= [];
gdjs.scene8Code.GDNewObject4Objects1= [];
gdjs.scene8Code.GDNewObject4Objects2= [];

gdjs.scene8Code.conditionTrue_0 = {val:false};
gdjs.scene8Code.condition0IsTrue_0 = {val:false};
gdjs.scene8Code.condition1IsTrue_0 = {val:false};


gdjs.scene8Code.eventsList0 = function(runtimeScene) {

{


gdjs.scene8Code.condition0IsTrue_0.val = false;
{
gdjs.scene8Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "r");
}if (gdjs.scene8Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "scene1", false);
}}

}


{


gdjs.scene8Code.condition0IsTrue_0.val = false;
{
gdjs.scene8Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.scene8Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewObject3"), gdjs.scene8Code.GDNewObject3Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewObject4"), gdjs.scene8Code.GDNewObject4Objects1);
{for(var i = 0, len = gdjs.scene8Code.GDNewObject3Objects1.length ;i < len;++i) {
    gdjs.scene8Code.GDNewObject3Objects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.scene8Code.GDNewObject4Objects1.length ;i < len;++i) {
    gdjs.scene8Code.GDNewObject4Objects1[i].setOpacity(0);
}
}}

}


{


gdjs.scene8Code.condition0IsTrue_0.val = false;
{
gdjs.scene8Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.9, "K");
}if (gdjs.scene8Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewObject3"), gdjs.scene8Code.GDNewObject3Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewObject4"), gdjs.scene8Code.GDNewObject4Objects1);
{for(var i = 0, len = gdjs.scene8Code.GDNewObject3Objects1.length ;i < len;++i) {
    gdjs.scene8Code.GDNewObject3Objects1[i].setOpacity(1000);
}
}{for(var i = 0, len = gdjs.scene8Code.GDNewObject4Objects1.length ;i < len;++i) {
    gdjs.scene8Code.GDNewObject4Objects1[i].setOpacity(1000);
}
}}

}


};

gdjs.scene8Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.scene8Code.GDNewObjectObjects1.length = 0;
gdjs.scene8Code.GDNewObjectObjects2.length = 0;
gdjs.scene8Code.GDNewObject2Objects1.length = 0;
gdjs.scene8Code.GDNewObject2Objects2.length = 0;
gdjs.scene8Code.GDNewObject3Objects1.length = 0;
gdjs.scene8Code.GDNewObject3Objects2.length = 0;
gdjs.scene8Code.GDNewObject4Objects1.length = 0;
gdjs.scene8Code.GDNewObject4Objects2.length = 0;

gdjs.scene8Code.eventsList0(runtimeScene);
return;

}

gdjs['scene8Code'] = gdjs.scene8Code;
