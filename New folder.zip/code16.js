gdjs.scene17Code = {};
gdjs.scene17Code.GDNewObjectObjects1= [];
gdjs.scene17Code.GDNewObjectObjects2= [];
gdjs.scene17Code.GDNewObject32Objects1= [];
gdjs.scene17Code.GDNewObject32Objects2= [];
gdjs.scene17Code.GDNewObject3Objects1= [];
gdjs.scene17Code.GDNewObject3Objects2= [];
gdjs.scene17Code.GDNewObject2Objects1= [];
gdjs.scene17Code.GDNewObject2Objects2= [];
gdjs.scene17Code.GDNewObject4Objects1= [];
gdjs.scene17Code.GDNewObject4Objects2= [];

gdjs.scene17Code.conditionTrue_0 = {val:false};
gdjs.scene17Code.condition0IsTrue_0 = {val:false};
gdjs.scene17Code.condition1IsTrue_0 = {val:false};


gdjs.scene17Code.eventsList0 = function(runtimeScene) {

{


gdjs.scene17Code.condition0IsTrue_0.val = false;
{
gdjs.scene17Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "r");
}if (gdjs.scene17Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "scene1", false);
}}

}


{


gdjs.scene17Code.condition0IsTrue_0.val = false;
{
gdjs.scene17Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.scene17Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewObject2"), gdjs.scene17Code.GDNewObject2Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewObject4"), gdjs.scene17Code.GDNewObject4Objects1);
{for(var i = 0, len = gdjs.scene17Code.GDNewObject2Objects1.length ;i < len;++i) {
    gdjs.scene17Code.GDNewObject2Objects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.scene17Code.GDNewObject4Objects1.length ;i < len;++i) {
    gdjs.scene17Code.GDNewObject4Objects1[i].setOpacity(0);
}
}}

}


{


gdjs.scene17Code.condition0IsTrue_0.val = false;
{
gdjs.scene17Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.9, "L");
}if (gdjs.scene17Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewObject2"), gdjs.scene17Code.GDNewObject2Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewObject4"), gdjs.scene17Code.GDNewObject4Objects1);
{for(var i = 0, len = gdjs.scene17Code.GDNewObject2Objects1.length ;i < len;++i) {
    gdjs.scene17Code.GDNewObject2Objects1[i].setOpacity(1000);
}
}{for(var i = 0, len = gdjs.scene17Code.GDNewObject4Objects1.length ;i < len;++i) {
    gdjs.scene17Code.GDNewObject4Objects1[i].setOpacity(1000);
}
}}

}


};

gdjs.scene17Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.scene17Code.GDNewObjectObjects1.length = 0;
gdjs.scene17Code.GDNewObjectObjects2.length = 0;
gdjs.scene17Code.GDNewObject32Objects1.length = 0;
gdjs.scene17Code.GDNewObject32Objects2.length = 0;
gdjs.scene17Code.GDNewObject3Objects1.length = 0;
gdjs.scene17Code.GDNewObject3Objects2.length = 0;
gdjs.scene17Code.GDNewObject2Objects1.length = 0;
gdjs.scene17Code.GDNewObject2Objects2.length = 0;
gdjs.scene17Code.GDNewObject4Objects1.length = 0;
gdjs.scene17Code.GDNewObject4Objects2.length = 0;

gdjs.scene17Code.eventsList0(runtimeScene);
return;

}

gdjs['scene17Code'] = gdjs.scene17Code;
