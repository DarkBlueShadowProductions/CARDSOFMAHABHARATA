gdjs.CCode = {};
gdjs.CCode.GDNewObjectObjects1= [];
gdjs.CCode.GDNewObjectObjects2= [];
gdjs.CCode.GDNewObject2Objects1= [];
gdjs.CCode.GDNewObject2Objects2= [];

gdjs.CCode.conditionTrue_0 = {val:false};
gdjs.CCode.condition0IsTrue_0 = {val:false};
gdjs.CCode.condition1IsTrue_0 = {val:false};


gdjs.CCode.eventsList0 = function(runtimeScene) {

{


gdjs.CCode.condition0IsTrue_0.val = false;
{
gdjs.CCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.CCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "scene1", false);
}}

}


};

gdjs.CCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.CCode.GDNewObjectObjects1.length = 0;
gdjs.CCode.GDNewObjectObjects2.length = 0;
gdjs.CCode.GDNewObject2Objects1.length = 0;
gdjs.CCode.GDNewObject2Objects2.length = 0;

gdjs.CCode.eventsList0(runtimeScene);
return;

}

gdjs['CCode'] = gdjs.CCode;
